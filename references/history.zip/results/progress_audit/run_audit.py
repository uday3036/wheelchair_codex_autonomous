"""Replay existing notebook algorithms without modifying the project baseline.

Run from any directory: python results/progress_audit/run_audit.py
Requires the repository dependencies. Figures, logs and metrics are saved here.
Notebook installation, gallery, reference-image and ZIP cells are skipped.
Mobility replay skips rendering by default; add --render for GIFs.
"""
import contextlib
import json
import os
from pathlib import Path
import platform
import sys
import tempfile

os.environ.setdefault("MPLCONFIGDIR", "/tmp/wheelchair-audit-matplotlib")
os.environ.setdefault("MUJOCO_GL", "cgl" if sys.platform == "darwin" else "egl")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
RENDER = "--render" in sys.argv


def cells(name):
    return json.loads((ROOT / "notebooks" / name).read_text())["cells"]


def run_cell(ns, notebook, index):
    exec(compile("".join(notebook[index]["source"]), f"notebook-cell-{index}", "exec"), ns)


def save_figures(prefix):
    count = [0]
    def save():
        for number in plt.get_fignums():
            count[0] += 1
            plt.figure(number).savefig(OUT / f"{prefix}_{count[0]:02d}.png", dpi=120)
        plt.close("all")
    plt.show = save


def contact_geometry(model, state):
    mujoco.mj_forward(model, state)
    return [{"geom1": model.geom(c.geom1).name, "geom2": model.geom(c.geom2).name,
             "distance_m": float(c.dist)} for c in state.contact if c.dist < -.001]


def coursework():
    notebook = cells("coursework_updated.ipynb")
    ns = {"__name__": "__audit__"}
    save_figures("coursework")
    previous = Path.cwd()
    with tempfile.TemporaryDirectory(prefix="wheelchair-coursework-") as directory:
        try:
            os.chdir(directory)
            for index in [2, 4, 5, 8, 9, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36, 38, 40]:
                print("Executing coursework cell", index, flush=True)
                run_cell(ns, notebook, index)
            model = ns["model"]
            errors = []
            rng = np.random.default_rng(20261020)
            for q in rng.uniform(ns["Q_LO"], ns["Q_HI"], size=(100, 6)):
                ns["set_arm_q"](ns["data"], q, np.zeros(6))
                errors.append(np.linalg.norm(ns["forward_kinematics"](q)[:3, 3] - ns["data"].site_xpos[ns["EEF_SITE"]]))
            result = {
                "nq": model.nq, "nv": model.nv, "nu": model.nu,
                "fk_max_error_m_100_configurations": max(errors),
                "jacobian_fd_max_error": float(np.max(np.abs(ns["J_test"][:3] - ns["J_fd"]))),
                "ik_success": bool(ns["IK_INFO"]["success"]),
                "ik_error_m": ns["IK_INFO"]["error_m"],
                "rrt_nodes": None if ns["planned_path"] is None else len(ns["planned_path"]),
                "trials": {},
            }
            initial = mujoco.MjData(model)
            initial.qpos[ns["ARM_QPOS"]] = ns["Q_REFERENCE_START"]
            initial.qpos[ns["SECONDARY_QPOS"]] = ns["SECONDARY_STOWED"]
            result["initial_penetrations_over_1mm"] = contact_geometry(model, initial)
            result["rrt_start_in_collision"] = bool(ns["arm_obstacle_collision"](ns["Q_START_PLAN"]))
            result["rrt_goal_in_collision"] = bool(ns["arm_obstacle_collision"](ns["Q_IK"]))
            for label in ["trial_nominal", "trial_challenge", "trial_low_gain"]:
                trial = ns[label]
                result["trials"][label] = trial["metrics"]
                np.savez_compressed(OUT / f"{label}.npz", **{k: v for k, v in trial.items() if k != "metrics"})
            return result
        finally:
            os.chdir(previous)


def mobility():
    notebook = cells("wheelchair_milestone1E_rear_drive_control.ipynb")
    ns = {"np": np, "mujoco": mujoco, "plt": plt}
    run_cell(ns, notebook, 4)
    # Keep the original controller and simulation loop. Remove only rendering
    # and the automatic notebook trial runner for the headless replay.
    source = "".join(notebook[6]["source"]).split("# Only two systems")[0]
    if not RENDER:
        source = source.replace("renderer=mujoco.Renderer(m,height=360,width=480)", "renderer=None")
        source = source.replace("if step%frame_every==0:", "if False:")
        source = source.replace("renderer.close()", "pass")
    exec(compile(source, "mobility-simulation-cell", "exec"), ns)
    result = {}
    data_by_trial = {}
    for label, variant, mode in [("Rocker equal rear speeds", "rocker", "equal"),
                                  ("Rocker curvature drive", "rocker", "curvature"),
                                  ("Rigid curvature drive", "rigid", "curvature")]:
        path = ROOT / "models" / f"wheelchair_m1e_{variant}.xml"
        model = mujoco.MjModel.from_xml_path(str(path))
        state = mujoco.MjData(model)
        mujoco.mj_forward(model, state)
        positions = {name: state.xpos[model.body(name).id].tolist() for name in
                     ["wheel_rear_left", "wheel_front_left", "wheel_mid_left",
                      "wheel_rear_right", "wheel_front_right", "wheel_mid_right"]}
        mapping = {model.actuator(i).name: model.joint(int(model.actuator_trnid[i, 0])).name for i in range(model.nu)}
        refs = ns["refs"](model)
        state.qpos[refs["arm_p"]] = ns["ARM_HOME"]
        state.qpos[refs["sec_p"]] = ns["SEC_HOME"]
        penetrations = contact_geometry(model, state)
        axis_alignment = {}
        for geom in refs["wheel_geom"].values():
            joint = model.body_jntadr[model.geom_bodyid[geom]]
            axis_alignment[model.geom(geom).name] = float(abs(state.geom_xmat[geom].reshape(3, 3)[:, 2] @ state.xaxis[joint]))
        data, frames = ns["simulate"](path, drive_mode=mode)
        data_by_trial[label] = data
        np.savetxt(OUT / f"{variant}_{mode}.csv", data, delimiter=",", header="time,x,y,z,yaw,v_command,steer_command,steer_l,steer_r,caster_l,caster_r,rear_speed_l,rear_speed_r,rear_torque_l,rear_torque_r,normal_rear_l,normal_rear_r,normal_front_l,normal_front_r,normal_middle_l,normal_middle_r,main_error_norm_deg,aux_error_norm_deg")
        mask = (data[:, 0] >= 1.5) & (data[:, 0] < 3.5)
        turn = data[mask]
        distance = np.linalg.norm(np.diff(turn[:, 1:3], axis=0), axis=1).sum()
        item = {
            "nq": model.nq, "nv": model.nv, "nu": model.nu,
            "mass_kg": float(model.body_mass.sum()), "nominal_wheel_centres_m": positions,
            "actuator_joint_mapping": mapping,
            "initial_penetrations_over_1mm": penetrations,
            "wheel_cylinder_axle_abs_dot": axis_alignment,
            "turn_distance_m": float(distance),
            "turn_yaw_deg": float(np.rad2deg(np.unwrap(turn[:, 4])[-1] - np.unwrap(turn[:, 4])[0])),
            "ideal_yaw_using_0_61_m_deg": float(np.rad2deg(distance / .61 * np.tan(np.deg2rad(20)))),
            "ideal_yaw_using_0_82_m_deg": float(np.rad2deg(distance / .82 * np.tan(np.deg2rad(20)))),
            "mean_turn_steer_deg": np.rad2deg(turn[:, 7:9].mean(axis=0)).tolist(),
            "mean_turn_rear_rad_s": turn[:, 11:13].mean(axis=0).tolist(),
            "mean_turn_rear_torque_Nm": turn[:, 13:15].mean(axis=0).tolist(),
            "mean_turn_normal_load_N": dict(zip(ns["GEOMS"], turn[:, 15:21].mean(axis=0).tolist())),
            "peak_arm_error_norm_deg": data[:, 21:23].max(axis=0).tolist(),
            "height_range_m": [float(data[:, 3].min()), float(data[:, 3].max())],
            "finite": bool(np.isfinite(data).all()),
        }
        if RENDER:
            import imageio
            imageio.mimsave(OUT / f"{variant}_{mode}.gif", frames, duration=.1, loop=0)
        result[label] = item
        print(label, json.dumps(item), flush=True)
    ns["results"] = data_by_trial
    save_figures("mobility")
    run_cell(ns, notebook, 8)
    return result


if __name__ == "__main__":
    with (OUT / "execution.log").open("w") as log, contextlib.redirect_stdout(log):
        metrics = {"environment": {"python": platform.python_version(), "platform": platform.platform(),
                                    "mujoco": mujoco.__version__, "numpy": np.__version__, "rendered": RENDER},
                   "coursework": coursework(), "mobility": mobility()}
        (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    print("Audit complete:", OUT / "metrics.json")
