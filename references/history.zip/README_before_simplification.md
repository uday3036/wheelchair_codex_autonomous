# Autonomous dual-arm assistive wheelchair

**Moving MuJoCo window:** replay the saved autonomous physics recording with
`.venv/bin/mjpython scripts/replay_autonomous.py`. For the professor demonstration
saved outside the project, add `--directory /tmp/wheelchair_professor_demo`.
SPACE pauses/resumes, R restarts, and 1/2/3 select half/normal/double speed.
This is interactive 3D playback of recorded states, not a fresh controller run.
It does not change the robot model or send hardware commands. See
[PLAYBACK.md](docs/PLAYBACK.md).

**Design files:** [assets/README.md](assets/README.md) explains the organised
MJCF XML, URDF, OBJ and STL exports, design viewer and regeneration commands.
Use `assets/mjcf/wheelchair_robot.xml` for the robot, `assets/urdf/wheelchair.urdf`
for articulated interchange, and `assets/meshes/assemblies/wheelchair_folded.obj`
for a complete static design. These are generated from the existing canonical
model and task builder; simulation entry points are preserved. Future mechanical
engineering requirements are in [hardware/DESIGN_REVIEW.md](hardware/DESIGN_REVIEW.md).

```text
assets/       generated robot descriptions, meshes and provenance inventory
hardware/     future physical design review and measured component documentation
models/       canonical MuJoCo source model (preserved)
src/          canonical algorithms, task builders and controllers (preserved)
scripts/      notebook checks, asset exporter and design inspection viewer
notebooks/    single active experiment notebook
tests/        physics, robotics and asset consistency checks
results/      recorded experiments, plots and animations
docs/         mathematical explanations and validation reports
references/   coursework requirements and historical recovery archive
```

Open **[notebooks/wheelchair_current.ipynb](notebooks/wheelchair_current.ipynb)**. This is the single active notebook containing the current setup, model checks, contact and suspension comparisons, numerical results, plots, MuJoCo animations and regression tests. It uses the canonical source modules rather than embedding another controller.

**Current focus: autonomous sensing, approach and bottle delivery in one continuous MuJoCo scene.** Open the notebook and use `WORKFLOW = "autonomous"` (the default), or run:

```sh
.venv/bin/python -B -m src.run_autonomous --acknowledge-passenger --compare --render
```

**Travel and idle storage:** both arms now fold into physical protective cases with closed sliding covers. Driving is inhibited until measured containment and cover closure are confirmed. The stopped chair opens the cases and deploys the arms at the table; after supported delivery, the empty arms return to their cases. Arms retaining an object remain deployed. See [STOWAGE_VALIDATION.md](docs/STOWAGE_VALIDATION.md).

The chair detects the simulated blue bottle from ideal color/depth rays, verifies tabletop evidence, plans through LiDAR-observed free space, drives with rear-wheel feedback and active front steering, brakes at the table, and continues into pickup, auxiliary holding, physical cap removal, cap disposal and supported recipient delivery. The base remains free throughout: rear motor braking holds it during manipulation. The middle casters remain passive. One model and physical state continue across navigation and manipulation; the bottle is never teleported or attached to a gripper.

Results and actual MuJoCo animation are under `results/autonomous_validation/`. All seven requested comparison outcomes and 82 tests pass. The cased-arm notebook passes fresh-kernel execution in 276.68 seconds, including six visual outputs. The comparison checks sideways casters, a small approach offset, absent bottle, blocked route, no acknowledgement and absent recipient support. See [AUTONOMOUS_VALIDATION.md](docs/AUTONOMOUS_VALIDATION.md) for acceptance gates, algorithms, evidence and scope. This is a bounded flat-floor forward approach using calibrated simulated localization and an ideal color/depth bottle class detector; arbitrary-room navigation, reverse caster alignment and hardware operation remain unvalidated. Acknowledgement is an explicit simulated input. Omitting its flag must prevent passenger release.

Select `"delivery"` for the earlier stationary complete task, `"grasp"` for pickup/retention comparisons, or `"mobility"`/`"all"` for historical experiments. The original canonical model remains unchanged; autonomous scenes derive the previously tested clearance mounts, 120 N m/rad rocker springs and optional 40 mm middle tires from it. These remain uncalibrated design assumptions.

The complete stationary task uses a separate free cap with an illustrative compliant thread, physical cap-bin support, measured primary support before auxiliary release, measured bottle-position correction and an explicit simulated acknowledgement before recipient approach. Final release requires measured support from a prescribed hand surrogate. The bottle and cap have no gripper attachments. This is a known-pose 0.3 kg simulation; it does not establish real screw calibration, human hand biomechanics, navigation or real passenger readiness. See [DELIVERY_VALIDATION.md](docs/DELIVERY_VALIDATION.md).

```sh
.venv/bin/python -m src.run_delivery --acknowledge-passenger --compare --render
```

Results, force graphs, stage events, a storyboard and complete MuJoCo animations are saved under `results/delivery_validation/`. The nominal sequence passes all delivery gates, all three failure controls block passenger release, and 29 manipulation tests pass. The active notebook executes successfully in a fresh kernel. The comparison includes a jammed cap, no acknowledgement and absent recipient support; each must block passenger release. Omitting `--acknowledge-passenger` deliberately retains the bottle. In the notebook this input is explicitly named `SIMULATED_PASSENGER_ACKNOWLEDGEMENT`.

The primary arm now uses the supplied photo's pedestal/link-plate style while retaining six arm joints and the tested wheelchair-scale dimensions: 300 mm upper arm, 250 mm forearm, 195 mm wrist-to-grasp offset and 160 mm pedestal-to-shoulder height. The notebook shows actual before/after MuJoCo previews. See [ARM_DESIGN.md](docs/ARM_DESIGN.md); standalone preview command: `.venv/bin/python -m src.preview_arm`.

From the VS Code terminal in the project root:

```sh
.venv/bin/python -m src.run_grasp --compare --render
```

This runs six grasp comparisons and saves CSV, metrics, poses, graphs and GIFs under `results/grasp_validation/`. The nominal 0.3 kg contact grasp passes; the 0.6 kg payload and other comparison/negative-control failures remain explicit. Only the base is welded to the lab frame; the bottle has no attachment constraint. Two actuated jaw slides are added in a derived fixture while both arms and the canonical mobile XML are preserved. See [GRASP_VALIDATION.md](docs/GRASP_VALIDATION.md).

For the nominal case only, omit `--compare`. The command's exit status checks nominal success; it does not imply every comparison passed. This command covers reach–grasp–lift–hold. The added transfer experiment below continues the same free-bottle physics state through auxiliary support, primary release and withdrawal.

The 0.3 kg bottle now passes **15-second auxiliary-only holding** at the tested nominal, 15 mm nearer and 15 mm farther pickup positions. A 40 mm raised pregrasp removes the earlier open-jaw collision. The derived auxiliary tool has a 95 mm pad offset for palm clearance. Failed auxiliary support blocks handover release, retains primary support and returns the bottle to the table; primary release requires sustained measured table support. Both arms retain their six/three joints, gains and force/torque caps. The auxiliary begins in a selected waiting posture. The 0.6 kg payload, arbitrary poses, post-release recapture, real cap calibration and real passenger delivery remain unresolved. The derived complete simulation task is documented above. See [RETENTION_VALIDATION.md](docs/RETENTION_VALIDATION.md).

```sh
.venv/bin/python -m src.run_transfer --compare --retention --render
```

Outputs are under `results/transfer_validation/`. The same active notebook runs this comparison and shows the recorded MuJoCo animations, before/after pickup comparison, force/drift/recovery graphs and 21 tests. See [TRANSFER_VALIDATION.md](docs/TRANSFER_VALIDATION.md) for the NumPy algorithms, force interlock, measured limitations and reproducible checks. The transfer command returns success only if all requested positive transfer trials pass and the negative controls block handover release and complete supported table recovery; expected negative controls are still recorded as physical transfer failures.

## Setup and run

From the project root (validated with Python 3.9.6):

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m ipykernel install --prefix .venv --name wheelchair --display-name "Wheelchair (.venv)"
```

In VS Code, select **Wheelchair (.venv)** or `.venv/bin/python`, restart the kernel and choose **Run All**. The notebook works when opened from the project root or `notebooks/`. Rendering uses CGL on macOS and EGL on Linux; set `RENDER = False` in the notebook if offscreen graphics is unavailable. Keep the full project folder: the notebook imports `src/` and loads `models/`.

After project source updates, restart the notebook kernel and run all cells from the top. Setup refreshes project imports and prints the loaded `src/model.py` path and function signature. This prevents an older cached loader from causing `unexpected keyword argument 'caster_outboard_offset'` during animation replay. Replay cells use the refreshed model module. Printed mobility `FAIL` results in the diagnostic comparisons still represent known physical failures; they are separate from Python exceptions.

Run checks or experiments without opening the notebook:

```sh
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python scripts/check_notebooks.py
.venv/bin/python -m src.run_experiments --compare --rocker-stiffness 120
.venv/bin/python -m src.run_experiments --steering-compare --rocker-stiffness 120 --output results/steering_validation
.venv/bin/python -m src.run_experiments --integral-compare --steering-mode ackermann --rocker-stiffness 120 --output results/integral_validation
```

Add `--render` to render every trial, or `--scenario left` to run one scenario. The notebook renders representative contact/steering comparisons, the forward PI candidate and diagnostic reverse animations. Contact results are under `results/current/`; steering results under `results/steering_validation/`; staged PI and caster diagnostics under `results/integral_validation/`, `results/caster_validation/` and `results/caster_clearance_validation/`. The executed notebook and execution summary are under `results/notebook_checks/`. Outputs are replaced on rerun; use `--output results/my_run` to preserve a separate experiment.

Steering comparison keeps gains unchanged and tests shared-angle versus Ackermann targets in nine scenarios per mode. Shared steering remains the default; use `--steering-mode ackermann` to select the candidate explicitly. JSON reports distinguish posture/contact regression `passed` from full `mobility_passed`. To require speed/curvature/braking acceptance at the CLI, add `--require-mobility-pass`; known accuracy failures then produce a nonzero exit code. Do not combine `--compare` and `--steering-compare`. See [STEERING_VALIDATION.md](docs/STEERING_VALIDATION.md) for equations, thresholds and results, including reverse-turn slowdown.

Bounded integral feedback is optional: `--feedback-mode steering_pi` adds steering I, and `--feedback-mode steering_drive_pi` also adds rear-speed I. The staged `--integral-compare` runs all three feedback modes. Combined I passes the current forward-turn steady speed/curvature and braking gates; reverse turns remain limited by wheel/frame contacts. The notebook also runs longer, half-speed `--caster-compare` diagnostics with four caster starting orientations, including expected geometry failures. An optional `--caster-outboard-offset 0.09` is an exploratory in-memory clearance comparison and does not fix all dynamic failures. Comparison families are mutually exclusive. See [INTEGRAL_VALIDATION.md](docs/INTEGRAL_VALIDATION.md) for equations, state resets, bounds, diagnostics and commands. PD/shared steering and the canonical XML remain unchanged defaults.

## Active project

Passive alignment diagnostics and sensitivity comparisons are now in notebook section 11. Run `.venv/bin/python -m src.run_experiments --profile current --alignment-compare --output results/alignment_validation` for all 56 trials. Lower bearing/rolling resistance and a wide-tire pulse remain insufficient. Optional narrower middle tires improve 6/8 cases; adding a short steering pulse improves 7/8, with one speed-overshoot failure retained. These experiments do not alter the launcher's defaults. See [ALIGNMENT_VALIDATION.md](docs/ALIGNMENT_VALIDATION.md) for measured torques, width/inertia assumptions, commands and remaining limits.

Use `--caster-tire-half-width 0.02` for the narrow sensitivity, `--caster-resistance low_bearing|low_roll|low_both` for resistance probes, and `--alignment-steer-deg 20` with `--caster-compare` for the pulse. `--scenario mobility` runs all nine standard scenarios. The alignment comparison is another mutually exclusive family. Outputs under `results/alignment_validation/` include CSV, poses, complete failed checks, diagnostic plots and notebook-generated animations. Strict failures return 1 while retaining complete evidence.
Optional supported geometry is available with `--clearance-geometry`. It retains passive unlimited middle swivel/rolling, adds overhead supports/forks, and passes the sampled articulated clearance audit. Pre-aligned long reverse turns now pass; other initial orientations still fail, and the width increases substantially. This candidate is not adopted as the default. See [GEOMETRY_VALIDATION.md](docs/GEOMETRY_VALIDATION.md) for dimensions, results and limitations. The same notebook includes this comparison.

```sh
.venv/bin/python -m src.geometry_audit
.venv/bin/python -m src.run_experiments --geometry-compare --steering-mode ackermann --feedback-mode steering_drive_pi --rocker-stiffness 120 --require-mobility-pass --output results/geometry_validation/standard
.venv/bin/python -m src.run_experiments --caster-compare --clearance-geometry --steering-mode ackermann --feedback-mode steering_drive_pi --rocker-stiffness 120 --require-mobility-pass --output results/geometry_validation/caster
```

The two strict comparisons return 1 on known mobility failures while saving complete reports. Geometry results, plots, logs and selected animations are under `results/geometry_validation/`. `--geometry-compare` joins the mutually exclusive comparison families.


- `notebooks/wheelchair_current.ipynb`: the current notebook.
- `src/`: controller, model loader, synchronized simulation and experiment runner.
- `models/wheelchair_m1e_rocker.xml`: the single canonical mobile model.
- `tests/test_mobility.py`: geometry, controller and physics regressions.
- `docs/`: project context, initial audit, validated equations/results and cleanup record.
- `references/professor/course_requirements.txt`: the course requirements.
- `references/history.zip`: recovery archive of superseded notebooks/models, earlier reference samples and original audit artifacts. The controller-equivalence test reads its historical reference from this archive.
- `.venv/`: the working local Python environment; retain it for the installed notebook kernel.

The wrist-contact correction is in the canonical model. The original spring setting remains 45 N m/rad and fails the provisional 5° chassis-tilt target. The notebook explicitly selects the tested 120 N m/rad spring comparison, which passes the documented flat-floor arm/posture checks. This setting is not a measured spring specification or passenger-load validation.

Turning accuracy, navigation, robust bottle manipulation, cap opening and passenger handover remain unfinished. Stationary pickup and auxiliary-arm transfer are validated only within the documented fixture, sampled bottle positions and 15-second hold duration. Earlier NumPy FK/Jacobian/IK/RRT and fixed-base coursework experiments are preserved in `references/history.zip`, with their known limitations. See [CONTACT_VALIDATION.md](docs/CONTACT_VALIDATION.md), [PROJECT_CONTEXT.md](docs/PROJECT_CONTEXT.md) and [CLEANUP.md](docs/CLEANUP.md).
